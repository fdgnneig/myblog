Unification script to create a complete trustlet out of ".mdt" and ".bXX" files
