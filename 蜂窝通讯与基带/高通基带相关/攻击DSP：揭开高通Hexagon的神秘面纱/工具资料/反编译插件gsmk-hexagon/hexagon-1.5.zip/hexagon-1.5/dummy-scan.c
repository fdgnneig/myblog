int bfd_default_scan(void*x,void*y)
{
    return 1;
}
